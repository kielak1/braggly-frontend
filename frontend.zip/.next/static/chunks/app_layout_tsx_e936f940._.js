(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/styles_globals_8242287d.css",
    "static/chunks/node_modules_next_592334bc._.js",
    "static/chunks/components_f13c4cd3._.js"
  ],
  "source": "dynamic"
});
